ZVulDrill
=========

## Web漏洞演练平台 
![](http://x2know.qiniudn.com/28653d0c62ba00c36b90bd7046984cea_r.jpg) 
![](http://x2know.qiniudn.com/f078de7be140db6a63829cfe75be5cea_r.jpg) 
包含的漏洞有
- SQL注入
- XSS
- CSRF
- 文件包含
- 后台弱口令
- 文件上传
- 目录遍历
- 权限跨越  
  
## 安装方法:  
1.新建一个名为 zvuldrill 的数据库  
2.将sys文件夹下的 zvuldrill.sql 导入到新建数据库中  
3.在sys/config.php中设置根目录  

## 答疑
QQ交流群：516667587
